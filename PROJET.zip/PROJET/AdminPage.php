<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf8" />
	<link rel="stylesheet"  href="login.css"/>
	<meta name="viewport" content="width=device=width,initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="icon" href="favicon.png" />
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<title>Home</title>
</head>

<body class="container-fluid bg-light h-100">

	<div class="row h-20">

		<div class="col jumbotron jumbotron-fluid header text-center" style="background-image: url(pictures/background_picrossdone.jpg); background-size: 100%;">
			<div class="container for-about">
				<h1>Admin Page</h1>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
			<form method="post" action="AdminPageAction.php">
				<div class="form-group text-center">
					<label for="email" class="form-label">Utilisateur à supprimer</label>
					<select class="form-control" name="email" id="email">
						<option selected="selected">Email Utilisateur</option>
						<!--list dynamique qui affiche les email des personnes dans la base de donne-->
						<?php
						include("connexion.php");
						$txt="SELECT email FROM connexion WHERE email!='admin@host'";
						$res=mysqli_query($link,$txt);
						while($table=mysqli_fetch_row($res))                        
							echo "<option>".$table[0]."</option>"
						?>

					</select>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col">
							<div class="form-group text-center">
								<input type="submit" class=" btn btn-danger" value="SUPPRIMER" />
							</div>
						</div>
					</div>
				</div>
			</form>
			<form>
				<div class="row">
					<div class="col"></div>
					<div class="col-8">
						<div  style="Overflow-y:scroll;height:200px">
							<table class="table table-bordered">
								<thead>
									<th scope="col">Email</th>
									<th scope="col">Prenom</th>
								</thead>
								<tbody>
									<!--Affichage du tableau avec les utilsateurs -->
									<?php
									$txt="SELECT email,Name FROM comptes WHERE email!='admin@host'";
									$res=mysqli_query($link,$txt);
									while($table=mysqli_fetch_row($res))
									{
										echo "<tr>
										<td>$table[0]</td>
										<td>$table[1]</td>
										</tr>" ;       
									}
									?>
								</tbody>

							</table>
						</div>
					</div>           
					<div class="col"></div>
				</div> 
			</form>        

			<div class="row">
				<div class="col"></div>
				<div class="col-8 text-center">
					<!--lien vers la page de deconnexion pour arreter la session admin -->
					<a href="deconnexion.php"><-Retour a l'accueil</a>
					</div>
					<div class="col"></div>
				</div>
			</div>
			<div class="col-md-6">
				<h3>Week Picross</h3>
				<?php
				$compt=0;
				$compt2=0;
				$requete2="SELECT Name FROM picross";
				$result2=mysqli_query($link,$requete2);
				while ($ligne = mysqli_fetch_assoc($result2)) {
				$name[$compt]= $ligne['Name']; //On associe a chaque indice du tableau prenom le resultat de la requête 
				$compt++;

			}
			var_dump($name);
			$requete3="SELECT Author FROM picross";
			$result3=mysqli_query($link,$requete3);
			while ($ligne2 = mysqli_fetch_assoc($result3)) {
				$author[$compt2]= $ligne2['Author']; //On associe a chaque indice du tableau prenom le resultat de la requête 
				$compt2++;
			}
			?>
			
				<form method="POST" action="AdminPageAction2.php">
					<div class="container" style="overflow-y:scroll; height:300px;">
					<?php
					$nb = count($name);
					$checks[]=0;
					for($i=0;$i<$nb;$i++) { 
						?>
						<div class="form-row">
							<div class="col">
								<label>Title</label>
								<input type="text" name="Nom" id="Nom" value="<?php echo $name[$i];?>" class="form-control" disabled="disabled"/>
								<hr/>
							</div>
							<div class="col">
								<label>Name</label>
								<input type="text" name="Prénom" id="Prénom" value="<?php echo $author[$i];?>" class="form-control" disabled="disabled"/>
								<hr />
							</div>
							<div class="col" style="margin-top:5%;">
								<label class="form-check-label" for="exampleCheck1">Check </label>
								<?php
								echo " <input style=margin-left:6%; type=checkbox class=form-check-input id=$i name=author[] value=$author[$i]>";	
								?>
							</div>
						</div>
						<?php
					}
					?>
				</div>
					<input type="submit" class=" btn btn-danger" value="Valider" style="margin-left:60%;"/>
				</form>
			</div>
		</div>
	</body>






