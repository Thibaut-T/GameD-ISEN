<?php
	include("connexion.php");

	$email=0;
	
	//Regarde si la variables existe et comporte les bonnes valeurs
	 if($_POST["email"]=='Email utilisateur')
		header("location:AdminPage.php");

	if(isset($_POST["email"]))
		$email=$_POST["email"];

	//Suppression de tous les informations liées a un email
	$txt1="DELETE FROM connexion WHERE email='$email'";
	$txt3="DELETE FROM comptes WHERE email='$email'";
	$res1=mysqli_query($link,$txt1);
	$res3=mysqli_query($link,$txt3);

	//Renvoit vers la page de connexion
	header("location:AdminPage.php");
