<?php
include("Connexion.php");
setcookie("ErrorNewUser","",1);

//Valeur par défaut
$email=0;
$mdp1=0;
$mdp2=0;
$error=0;

//On fait en sorte que il y a bien des variables dans les POST
if(isset($_POST["email"]))
	$email=$_POST["email"];
if(isset($_POST["pass"]))
	$mdp1=$_POST["pass"];
if(isset($_POST["passconf"]))
	$mdp2=$_POST["passconf"];

//On regarde si le email existe deja 
$check_mail="SELECT Email FROM connexion";
$check_mail_result=mysqli_query($link,$check_mail);
while(($table=mysqli_fetch_row($check_mail_result)) && $error==0)
	if($table[0]==$email)	
		$error=1;
	
//On fait en sorte que les mots de passe correspondent
	if($mdp1!=$mdp2)
		$error=2;

	if($error==0)
	{	
	//On ajoute le nouvel utilisateur et on redirige vers la page de connexion
		$add_user1="INSERT INTO connexion (email,password) VALUES ('$email','$mdp1')";
		$add_user2="INSERT INTO comptes (email,password) VALUES ('$email','mdp1')";
		mysqli_query($link,$add_user1);
		mysqli_query($link,$add_user2);
		
		header("location:LoginPage.php");
	}
	else
	{
	//On redirige vers NewUtilisateur avec l'erreur
		setcookie("ErrorNewUser",$error,time()+600);		
		header("location:NewAccount.php");
	}