<?php
	include("connexion.php");

	if(isset($_POST['author'])){
		$tabCheck = $_POST['author']; //Recuperation dans un tableau de toutes les valeurs des checkboxs
		$nb=count($tabCheck);
		var_dump($tabCheck);
		for($i=0;$i<$nb;$i++){
			$requete="UPDATE picross SET Visibility=1 WHERE Author='$tabCheck[$i]'";
			$result=mysqli_query($link,$requete);
		}
	}
	//header("location:AdminPage.php");
	
