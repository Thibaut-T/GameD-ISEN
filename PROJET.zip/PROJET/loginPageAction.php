<?php
include("connexion.php");
$email=0;
$mdp=0;
$erreur=0;
if(isset($_POST["email"]))
	$email=$_POST["email"];
if(isset($_POST["pass"]))
	$mdp=$_POST["pass"];
$requete="SELECT password FROM connexion WHERE email='$email'";
$result=mysqli_query($link,$requete);
$result_rows=mysqli_fetch_assoc($result);
if($result_rows==NULL){
	$erreur=1;
}
else if($mdp!=$result_rows["password"]){
	$erreur=2;
}

var_dump($result_rows);
echo "C EST L ERREUR ";
echo $erreur;
if($mdp==$result_rows["password"] && $erreur==0)					/*Login réussi*/
{
	session_start();
	$_SESSION["utilisateur"]=$email;
	if($_SESSION["utilisateur"]=="admin@host")		/*Login d'un admin*/
		header("location:AdminPage.php");
	else header("location:home.php");
	
}
else
{
	setcookie("ErrorLogin",$erreur,time()+500);	
	header("location:LoginPage.php");				/*utilisateur n'existe pas*/
}
?>