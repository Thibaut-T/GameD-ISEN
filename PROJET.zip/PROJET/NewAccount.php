<!DOCTYPE html>
<html lang="fr">
<head>
	<meta charset="utf8" />
	<link rel="stylesheet"  href="login.css"/>
	<meta name="viewport" content="width=device=width,initial-scale=1.0">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="icon" href="favicon.png" />
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<title>Home</title>
	<script>
        function ShowPassword() {
            pwd = document.getElementById("pwd");
            if (pwd.type == "password")
                pwd.type = "text";
            else pwd.type = "password";
        }

    </script>    
</head>
<?php
$erreur=0;
if(isset($_COOKIE["ErrorLogin"]))
{
    $erreur=$_COOKIE["ErrorLogin"];
    setcookie("ErrorLogin","",1);    
}    
?>
<body class="container-fluid bg-light h-100">

    <div class="row h-20">

        <div class="col jumbotron jumbotron-fluid header text-center" style="background-image: url(pictures/background_picrossdone.jpg); background-size: 100%;">
         <div class="container for-about">
             <h1>Welcome to Picross</h1>
         </div>
     </div>
 </div>
 <div class="row">
    <div class="col"></div>
    <div class="col-8 border rounded">
        <form method="post" action="NewAccountAction.php">
            
            <div class="row form-group">

                <div class="col">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" name="email" id="email" required />
                    <!--check si il y a eu un renvoi d'erreur, dans ce cas= affiche le message-->
                    <?php
                    if($erreur==1)
                        echo "<small id='email' class='form-text text-danger'>*Email déjà pris</small>";                            
                    ?>
                </div>

            </div>

            <div class="row form-group">
                
                <div class="col">
                    <label for="pwd" class="form-label">Mot de passe </label>
                    <input type="password" class="form-control" name="pass" id="pwd" required/>
                    <!--check si il y a eu un renvoi d'erreur, dans ce cas= affiche le message-->
                    <?php
                    if($erreur==2)
                        echo "<small id='pwd' class='form-text text-danger'>*Les mots de passe ne correspondent pas</small>";                            
                    ?>
                </div>

            </div>

            <div class="row form-group">
                
                <div class="col">
                    <label for="pwdconf" class="form-label">Confirmer mot de passe</label>
                    <input type="password" class="form-control" name="passconf" id="pwdconf" required/>
                    <!--check si il y a eu un renvoi d'erreur, dans ce cas= affiche le message-->
                    <?php
                    if($erreur==2)
                        echo "<small id='pwdconf' class='form-text text-danger'>*Les mots de passe ne correspondent pas</small>";                            
                    ?>
                </div>

            </div>

            <div class="form-group text-center">                 
                <input type="submit" class="btn btn-primary" value="S'inscrire" />        
            </div>    
            
        </form>
    </div>
    <div class="col"></div>
</div>      
<!-- Liens vers les réseux sociaux-->
<footer style="padding-top:3%;">
    <div class="row">
        <div class="col"></div>
        <div class="col-6">
            <div class="row mt-2">

                <div class="col">
                    <a href="https://fr-fr.facebook.com/"><img src="pictures/fb.jpg" alt="Facebook" style="border-radius:100%;width:50px;"></a>
                </div>
                <div class="col">
                    <a href="https://twitter.com/explore"><img src="pictures/twitter.jpg" alt="Twitter" style="border-radius:100%;width:50px;"></a>
                </div>
                <div class="col">
                    <a href="https://www.youtube.com/?hl=fr&gl=FR"><img src="pictures/yt.png" alt="Youtube" style="border-radius:100%;width:50px;"></a>
                </div>
                <div class="col">
                    <a href="https://www.instagram.com/?hl=fr"><img src="pictures/insta.jpg" alt="Instagram" style="border-radius:100%;width:50px;"></a>
                </div>
                <div class="col">
                    <a href="https://www.pinterest.fr/"><img src="pictures/pinterest.jpg" alt="Pinterest" style="border-radius:100%;width:50px;"></a>
                </div>
                <div class="col">
                    <a href="https://www.reddit.com/"><img src="pictures/reddit.jpg" alt="Pinterest" style="border-radius:100%;width:50px;"></a>
                </div>

            </div>
            <div class="row">
                <div class="col">
                    <p class="text-muted text-center">© 2020 Picross™</p>
                </div>
            </div>
        </div>
        <div class="col"></div>
    </div>
</footer>