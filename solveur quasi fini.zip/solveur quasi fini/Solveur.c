#include "extraire.h"

int main() {
    setlocale(LC_ALL, "fr-FR");

    int colonnes = 7;
    int lignes = 7;
    picross Piiicross;
    if (Init_picross(&Piiicross, lignes, colonnes)) {
        //printf("\n\n%d\n\n", Piiicross.colonnes);
        Piiicross.nb_lignes[0] = "2 1"; //on defini les differentes informations des lignes
        Piiicross.nb_lignes[1] = "2 1 1";
        Piiicross.nb_lignes[2] = "4 1";
        Piiicross.nb_lignes[3] = "1 2";
        Piiicross.nb_lignes[4] = "1 2";
        Piiicross.nb_lignes[5] = "6";
        Piiicross.nb_lignes[6] = "3";

        Piiicross.nb_colonnes[0] = "1";
        Piiicross.nb_colonnes[1] = "3 2";
        Piiicross.nb_colonnes[2] = "6";
        Piiicross.nb_colonnes[3] = "1 2";
        Piiicross.nb_colonnes[4] = "2 1";
        Piiicross.nb_colonnes[5] = "3";
        Piiicross.nb_colonnes[6] = "6";
        
        /*Piiicross.solution[5] = CROIX;
        Piiicross.nb_lignes[0] = "1 1 3"; //on defini les differentes informations des lignes*/

        Afficher_picross(Piiicross);
        
        /*Piiicross.nb_lignes[0] = "2 2";
        Piiicross.nb_lignes[1] = "2 2";
        Piiicross.nb_lignes[2] = "6";
        Piiicross.nb_lignes[3] = "2 1";
        Piiicross.nb_lignes[4] = "5";
        Piiicross.nb_lignes[5] = "1 1";
        Piiicross.nb_lignes[6] = "1";

        Piiicross.nb_colonnes[0] = "1";
        Piiicross.nb_colonnes[1] = "3 2";
        Piiicross.nb_colonnes[2] = "4";
        Piiicross.nb_colonnes[3] = "3";
        Piiicross.nb_colonnes[4] = "1 1";
        Piiicross.nb_colonnes[5] = "3 1";
        Piiicross.nb_colonnes[6] = "6";*/
        
        //printf("%d", espacement(&Piiicross, 0, 1, 2, Ligne));
        //mettre_des_croix_autour(&Piiicross, instructions_tableau_simple(Piiicross.nb_lignes[4], 4, 2), 0, Piiicross.colonnes -1, 4, 2, Ligne);
        parcourt_ligne_et_colonne(&Piiicross);
        Afficher_picross(Piiicross);
    }
}