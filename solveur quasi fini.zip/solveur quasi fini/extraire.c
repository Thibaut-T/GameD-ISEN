#include "extraire.h"

int trouver_cases_max2(char* nb) {
    return (int)((strlen(nb) + 1) / 2);
}

int* instructions_tableau_simple(char* nb, int nb_case, int cases_max) {
    int* nb_tableau_simple = (int*)malloc(sizeof(int) * cases_max);
    char* chaine;
    char* end;
    chaine = nb;
    for (int i = 0; i < cases_max; i++) {
        *(nb_tableau_simple + i) = (int)strtol(chaine, &end, 10);
        chaine = end;
    }
    return nb_tableau_simple;
}

void Afficher_picross(picross tmp) {
    printf("\nNombre de cases remplie : %d", tmp.nb_cases);
    printf("\nNombre de colonnes remplie : %d", tmp.colonnes);
    printf("\nNombre de lignes remplie : %d\n", tmp.lignes);

    for (int x = 0; x < tmp.lignes; x++) {
        for (int y = 0; y < tmp.colonnes; y++)
            printf("%d ", tmp.solution[y + x * tmp.colonnes]);
        printf("\n");
    }
}

int espacement(picross* nonogram, int caseini, int ordre, int nb_coligne, int mode) {
    int nbvide = 0;
    int pos = caseini;
    while (((mode == Ligne && pos < nonogram->colonnes && nonogram->solution[pos + nonogram->colonnes * nb_coligne] != CROIX) || (mode == Colonne && nonogram->solution[nb_coligne + pos * nonogram->colonnes] != CROIX && pos < nonogram->lignes)) && pos >= 0) {
        pos += ordre;
        nbvide++;
    }

    return nbvide;
}

void evidences(picross* Picross, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) {
    int taillecompresse = 0;
    //printf("evidences");
    for (int i = 0; i < nbr_instruc; i++) {
        taillecompresse += *(instruction + i) + 1;
    }
    taillecompresse--;

    //printf("La taille compress�e de la ligne est %d", taillecompresse);
    int vartemp;
    int tmp = debut;
    int marge = longueur - debut - taillecompresse + 1;
    
    //printf("\nla marge est de %d\n\n", marge);
    for (int i = 0; i < nbr_instruc; i++) {
        if (marge < *(instruction + i)) {
            //printf("\n%d", instruction[i] - marge);
            for (int j = 0; j < instruction[i] - marge; j++) {
                if(mode==Ligne) Picross->solution[tmp + j + marge + Picross->colonnes * nb_coligne] = PLEIN;
                if (mode == Colonne) Picross->solution[nb_coligne + Picross->colonnes*(marge+j+tmp)] = PLEIN;
              //  printf("La %d eme case a ete modifi�\n", tmp + j);
            }
            if (marge == 0 && tmp + *(instruction + i) + 1 <= longueur) {
                vartemp = *(instruction + i) + tmp;
                if(mode==Ligne) Picross->solution[vartemp + Picross->colonnes * nb_coligne] = CROIX;
                if (mode == Colonne) Picross->solution[nb_coligne + Picross->colonnes*vartemp]=CROIX;
            }
        }
        tmp += *(instruction + i) + 1;
    }    
}

void AAAfffiche(picross* nonogram, int* instruction, int** possibilite, int nb_espace,int nb_instruc) {
    printf("test\n");
    int x = 0;
    while (x != nb_instruc) {
        printf("%d ", instruction[x]);
        x++;
    }
    printf(" |  ");
    for (int i = 0; i < nonogram->colonnes; i++) {
        printf("%d ", nonogram->solution[i]);
    }
    printf("\n\n");
    for (int i = 0; i < nb_espace; i++) {
        x = 0;
        while (possibilite[i][x] != 0) {
            printf("%d ", possibilite[i][x]);
            x++;
        }
        printf("\n");
    }
    printf("\n\n");
}

void silvain(picross* nonogram, int* instruction, int debut, int longueur, int indice) {
    int x = 0;
    while (x != indice) {
        printf("%d ", instruction[x]);
        x++;
    }
    printf(" |  ");
    for (int i = debut; i < debut + longueur; i++) {
        printf("%d ", nonogram->solution[i]);
    }
    printf("\n\n");
}

void division(picross* nonogram, int* instruction, int longueur, int nb_coligne, int nbr_instruc, int mode) {
    int nb_espace = 0, nb_instruction = 0, debut = 0, nb_case, decalage = 0, x, z, taillecomprime, indice, case_av = 0, case_ap = 0, totcase = 0, compteur, taillecompress = 0, place = 0, plein = 0, nombre = 0, sens = 0, demande = 0, evidence = 0;
    nb_instruction = nbr_instruc;
    //printf("hi");
    while (debut <= longueur) { // Calul du nombre d'espace entre un bord et les croix d�j� pr�sente
        debut += espacement(nonogram, debut, 1, nb_coligne, mode) + 1;
        nb_espace++;
       // printf("nb_espace = %d\n", debut);
    }

    if (nb_espace == 1) {
        //printf("nb_espace");
        return;
    }

    int** possibilite = (int**)malloc(sizeof(int*) * nb_espace); // Tableau qui va contenir les possibilt� d'accueille de chaque espace
    for (int i = 0; i < nb_espace; i++) {
        possibilite[i] = (int*)malloc(sizeof(int) * 10);
    }
    int* tmp = (int*)malloc(sizeof(int) * nb_instruction); // Tableau qui contiendra les instructions finiaux

    if (!possibilite || !tmp) {
        return;
    }
    debut = 0; // R�initialisation
    for (int i = 1; i <= nb_espace; i++) {   // Pour tous les espaces     
        nb_case = espacement(nonogram, debut, 1, nb_coligne, mode); // Nombre de cases disponibles dans l'espace
        debut += nb_case + 1;
        indice = 0;
        case_av = debut - nb_case - 1; // Nombre de cases disponibles avant cet espace
        for (int t = 0; t < nb_instruction; t++) {
            if (instruction[t] <= nb_case) { // Si la taille de l'instruction ne d�passe pas le nombre de cases disponibles
                taillecomprime = 0;
                totcase = 0;
                place = 0;
                for (int y = t - 1; y >= 0; y--) { // On calcule le nombre de cases que l'on a besion avant en fonction des instructions pr�c�dentes
                    totcase += instruction[y] + 1;
                }
                if (totcase <= case_av) { // Si on a assez de place pour les instructions pr�c�dentes
                    totcase = -1;
                    x = t;
                    while (x != nb_instruction && taillecomprime <= (nb_case + 1) && place != -1) {
                        taillecomprime += *(instruction + x) + 1;
                        if (taillecomprime <= (nb_case + 1)) {
                            compteur = 0;
                            for (int o = x + 1; o < nb_instruction; o++) {// On v�rifie s'il y a la place pour les instructions suivantes malgr�s la pr�sence de croix
                                for (int y = 0; y < instruction[o]; y++) {
                                    if ((case_av + taillecomprime + compteur + 1) > longueur) {
                                        place = -1;
                                        y = instruction[o];
                                        o = nb_instruction;
                                    }
                                    if ((mode == Ligne && nonogram->solution[case_av + taillecomprime + compteur + nonogram->colonnes * nb_coligne] == CROIX) || (mode == Ligne && nonogram->solution[nb_coligne + nonogram->colonnes * (case_av + taillecomprime + compteur)] == CROIX)) {
                                        y = -1;
                                    }
                                    compteur++;
                                }
                                compteur++;
                            }
                            if (place != -1) { // Si on a assez de place
                                possibilite[i - 1][indice] = instruction[x] * 100 + x * 10;
                                indice++;
                                x++;
                            }
                        }
                    }
                    if (x != t) {
                        t = x - 1;
                    }
                }
            }
        }
        possibilite[i - 1][indice] = 0; // Pour signifier qu'il n'y pas d'autres solutions
    }
    //AAAfffiche(nonogram, instruction, possibilite, nb_espace,nbr_instruc);
    for (int o = 0; o < 2; o++) { // On effectue 2 fois l'analyse du tableau
        debut = 0;
        for (int i = 0; i < nb_instruction; i++) {
            compteur = 0;
            indice = 0;
            for (int y = 0; y < nb_espace; y++) {  // On regarde si les instructions sont pr�sentes dans plusieurs espaces
                x = 0;
                while (y < nb_espace && possibilite[y][x] != 0) {
                    if (possibilite[y][x] == instruction[i] * 100 + i * 10 + 6 || possibilite[y][x] == instruction[i] * 100 + i * 10 + 5 || possibilite[y][x] == -1) compteur = -20;  // Si la possibilit� a d�j� un �tat
                    if (possibilite[y][x] == instruction[i] * 100 + i * 10) { // Si l'instruction est pr�sent dans un espace
                        compteur++;  // On ajoute 1 au compteur
                        indice = y;  // On sauvegarde dans quel espace elle est pr�sente
                        y++;         // On passe � l'epace suivant
                        x = -1;      // On r�initialise x
                    }
                    x++;
                }
            }
            if (compteur == 1) {   // Si l'instruction n'est pr�sente que dans un espace
                z = 0;
                while (possibilite[indice][z] != 0) {  // On modifie l'�tat de la possibilit� (+5 = Cette instruction est obligatoiremetn dans cette espace)
                    if (possibilite[indice][z] == instruction[i] * 100 + i * 10) {
                        possibilite[indice][z] += 5;
                    }
                    z++;
                }
            }

        }
        for (int i = 0; i < nb_espace; i++) {    // On va traiter les cas ou certaines case sont d�j� pleinne ce qui nous permet d'affinier nos conclusions
            plein = 0;
            nb_case = 0;
            while (((mode == Ligne && nonogram->solution[debut + nonogram->colonnes * nb_coligne] != CROIX) || (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * debut] != CROIX)) && debut <= longueur) {  // On regarde s'il y a une case pleine sur l'espace
                if ((mode == Ligne && nonogram->solution[debut + nb_coligne * nonogram->colonnes] == PLEIN) || (mode == Colonne && nonogram->solution[nb_coligne + debut * nonogram->colonnes] == PLEIN)) plein++;
                debut++;
                nb_case++;
            }
            debut++;
            if (plein == nb_case) { // Si il y a une instruction d�j� d�finie entre 2 croix
                x = 0;
                nombre = 0;
                compteur = 0;
                sens = -3;
                while (possibilite[i][x] != 0) {  // On recherche les instructions qui r�pondent � la contrainte
                    if ((int)(possibilite[i][x] / 100) == nb_case && ((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) != 5 && ((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) != 6 && possibilite[i][x] != -1) { // Il faut que l'�tat de cette possibilit� ne soit pas d�finie
                        possibilite[i][x] += 3; // Si cette instruction peut �tre celle qui correspont aux cases on modifie l'�tat (+3 = en attente de confirmation
                        nombre++;
                    }
                    if (((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) == 5) {  // On compte aussi le nombre d'instruction dont l'�tat est 5
                        compteur++;
                    }
                    x++;
                }
                if (nombre == 0 && compteur == 1) { // Si aucune instruction dont m'�tat est non fix� e r�ponde � l acontrainte mais qu'il existe une instruction avec un �tat 5
                    possibilite[i][0] = (((int)(possibilite[i][0] / 10)) * 10) + 6;   // On a trouv� l'inruction dont les cases sont d�j�. Donc changelent d'�tat (+6 = instruciton de l'espace ne provoquant pas d'appel � la fin)
                }
                else if (nombre == 1) { // sinon si on a une seule instruction qui entre on va changer son �tat en 6
                    sens = 3;
                }
                x = 0;
                while (possibilite[i][x] != 0) {  // Recherche de l'instruction pour changer son �tat
                    if (((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) == 3 && ((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) != 5 && ((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) != 6 && possibilite[i][x] != -1) {
                        possibilite[i][x] += sens;
                        if (sens == 3) {    // On supprime les autres possibilit�s de la ligne
                            possibilite[i][x + 1] = 0;  // 0 pour dire qu'il n'y a plus de possibilit� apr�s
                            z = x - 1;
                            while (z != -1) {
                                possibilite[i][x + 1] = -1; // Pour les possibilit�s situ�es avant on les supprimes (-1) 
                                z--;
                            }
                            for (int q = 0; q < nb_espace; q++) { // On supprime aussi l'instruction dans les autres lignes
                                z = 0;
                                while (possibilite[q][z] != 0) {
                                    if (possibilite[q][z] == (int)(possibilite[i][x] / 10) * 10) {
                                        possibilite[q][z] = -1;
                                    }
                                    z++;
                                }
                            }
                        }
                        nombre++;
                    }
                    x++;
                }
            }
            else if (plein > 0) { // S'il y a au moins 1 cases pleines
                /*if (evidence == 0) {  // On appel 1 seule fois la fonction �vidences pour remplire la ligne/colonne
                    evidences(nonogram, instruction, debut, longueur, nb_coligne, nbr_instruc, mode);
                    evidence++;
                }*/
                z = 0;
                compteur = 0;
                decalage = 0;
                while (possibilite[i][z] != 0) { // On regarde le nombre de possibilit� totale et celle qui ont un �tat 5
                    if (((possibilite[i][z])) - (((int)(possibilite[i][z] / 10)) * 10) == 5)compteur++;
                    if (possibilite[i][z] == -1) decalage++;
                    z++;
                }
                if (compteur == 0 && (z - decalage) == 1) { // S'il y n'a aucune possibilit� d'�tat 5  et que l'on a qu'une possibilit� au total
                    z = 0;
                    while (possibilite[i][z] != 0) {  // Son �tat devient 5
                        if ((((int)(possibilite[i][z] / 10)) * 10) != 0) {
                            possibilite[i][z] = (((int)(possibilite[i][z] / 10)) * 10) + 5;
                        }
                        z++;
                    }
                    for (int q = 0; q < nb_espace; q++) { // On supprime cette possibilt� dans les autres lignes
                        z = 0;
                        while (possibilite[q][z] != 0) {
                            if (possibilite[q][z] == (int)(possibilite[i][x] / 10) * 10) {
                                possibilite[q][z] = -1;
                            }
                            z++;
                        }
                    }
                }
                else if (compteur != z - decalage) { // S'il n'y a pas que des possibilit�s dont l'�tat est 5 
                    z = 0;
                    compteur = 0;
                    while (possibilite[i][z] != 0) { //
                        if (((possibilite[i][z])) - (((int)(possibilite[i][z] / 10)) * 10) == 0 && (possibilite[i][z] != -1)) { // Si l'�tat n'est pas fix�
                            for (int f = 0; f < nb_espace; f++) {
                                x = 0;
                                while (possibilite[f][x] != 0) { //On cherche si l'instruction a un �tat 5 autre part
                                    if (((possibilite[f][x])) - (((int)(possibilite[f][x] / 10)) * 10) == 5 && (possibilite[f][x]) == (possibilite[i][z] + 5))compteur++;
                                    x++;
                                }
                            }
                            if (compteur == 0) { // Si l'intruction n'a pas d'�tat fixe autre part on ne peut pas conclure sur cet espace et on remet donc toutes les possibilt� de cette � l'�tat 0
                                x = 0;
                                while (possibilite[i][x] != 0) {
                                    if (((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) == 5) {
                                        possibilite[i][x] = (int)(possibilite[i][x] / 10) * 10;
                                    }
                                    x++;
                                }
                            }
                        }
                        z++;

                    }
                }
            }

        }
    }
    //AAAfffiche(nonogram, instruction, possibilite, nb_espace,nbr_instruc);
    debut = 0;

    for (int i = 0; i < nb_espace; i++) {
        x = 0;
        indice = 0;
        while (possibilite[i][x] != 0) { // S'il on est sure que l'�l�ment est dans cet espace alors on l'ajoute au tableau des instructions que l'on va envoyer
            if (((possibilite[i][x])) - (((int)(possibilite[i][x] / 10)) * 10) == 5) { // Si l'�tat est 6 c'est que cette instructino a d�j� �t� trait� on a donc pas besoin de fair un appel de fonction
                tmp[indice] = (int)(possibilite[i][x] / 100);
                indice++;
            }
            x++;
        }
        //printf("debut:%d",debut);
        nb_case = espacement(nonogram, debut, 1, nb_coligne, mode); // Longueur de notre espace pour pouvoir l'utiliser comme argument
        //printf("\nnb_case: %d\n", nb_case);
        if (indice != 0) { // S'il y a des instructions
            //silvain(nonogram, tmp, debut, nb_case, indice);
            evidences(nonogram, tmp, debut, debut+nb_case-1, nb_coligne, indice, mode);
        }
        debut += nb_case + 1; // Pour le d�part du prochain appel
        }
    free(tmp);
    free(possibilite);
}

int changement(picross nonogram, int* chang) {
    int changement = 0;
    for (int i = 0; i < nonogram.lignes; i++) {
        for (int y = 0; y < nonogram.colonnes; y++) {
            if (nonogram.solution[y + i * nonogram.colonnes] != *(chang +y + i * nonogram.colonnes)) {
                changement++;
                
                *(chang +y + i*nonogram.colonnes) = nonogram.solution[y + i * nonogram.colonnes];
            }
        }
    }

    if (changement==0) {
        return 0;
    }
    else {
        return 1;
    }
}

void mettre_des_croix_autour(picross* nonogram, int* instructions, int case_debut, int case_fin, int nb_coligne, int nbr_instruc, int mode) {
    int instruction_max = 0; //instruction_max est la variable contenant l'instruction ayant la valeur la plus �lev�e.
    for (int i = 0; i < nbr_instruc; i++) {
        if (instructions[i] > instruction_max)
            instruction_max = instructions[i];
    }
    //printf("instruction max: %d\n", instruction_max);
    int debut_croix = NULL, fin_croix = NULL, tmp = 0, compteur_cases = 0;
    int i = case_debut;
    //printf("debut : %d, fin : %d", case_debut, case_fin);
    while (i <= case_fin) { //On commence ici la recherche de cases dans l'intervalle choisi.
        if ((mode == Ligne && nonogram->solution[i + nonogram->colonnes * nb_coligne] == PLEIN) || (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * i] == PLEIN)) //Si la case est pleine, la variable tmp s'incr�mente.
            compteur_cases++;
        else { //Si la case n'est pas pleine, le compteur prend alors la valeur de la cha�ne de cases pleines.
            compteur_cases = 0;
        }
        //printf("valeur de i: %d, valeur de compteur case: %d\n", i, compteur_cases);
        if (compteur_cases == instruction_max) { //Si on retrouve dans la ligne/colonne l'instruction la plus grande...
            //printf("valeur de i: %d\n", i);
            if (i+1<= case_fin) //On regarde si la croix la plus �loign�e du bord n'existe pas.
                fin_croix = i + 1;
            if ( i - compteur_cases > 0) //On regarde si la croix la plus proche du bord n'existe pas.
                debut_croix = i - compteur_cases;
            break; //On peut donc sortir de la boucle while.
        }
        i++;
    }
    if (debut_croix != NULL) { //Ici, si les croix existent, alors on les place.
        //printf("%d\n", debut_croix);
        if (mode == Ligne) nonogram->solution[debut_croix + nonogram->colonnes * nb_coligne] = CROIX;
        if (mode == Colonne) nonogram->solution[nb_coligne + nonogram->colonnes * debut_croix] = CROIX;
    }
    if (fin_croix != NULL){
        if (mode == Ligne) nonogram->solution[fin_croix + nonogram->colonnes * nb_coligne] = CROIX;
        if (mode == Colonne) nonogram->solution[nb_coligne + nonogram->colonnes * fin_croix] = CROIX;
    }
}

void coligne_complet(picross* nonogram, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) {
    if(mode==Ligne) printf("Mode Ligne, actuellement a la ligne %d",nb_coligne);
    if (mode == Colonne) printf("Mode Colonne, actuellement a la colonne %d", nb_coligne);
    Afficher_picross(*nonogram);
    int cases_a_noircir = 0;
    for (int i = 0; i < nbr_instruc; i++) {
        cases_a_noircir += instruction[i];
    }
    printf("\nLe nombre de case a noircir est:%d",cases_a_noircir);
    int nbr_cases_noir_actu = 0;
    for (int i = debut; i <= longueur; i++) {
        if (mode == Ligne && nonogram->solution[i + nonogram->colonnes * nb_coligne] == PLEIN)  nbr_cases_noir_actu++;
        if (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * i] == PLEIN) nbr_cases_noir_actu++;
    }
    printf("\nLe nombre de case actuellement sur grille est:%d\n", nbr_cases_noir_actu);
    if (nbr_cases_noir_actu == cases_a_noircir) {
        for (int i = debut; i <= longueur; i++) {

            if ((mode == Ligne && nonogram->solution[i + nonogram->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * i] != PLEIN))
            {
                if (mode == Ligne) nonogram->solution[i + nonogram->colonnes * nb_coligne] = CROIX;
                if (mode == Colonne) nonogram->solution[nb_coligne + nonogram->colonnes * i] = CROIX;
            }
        }
    }
    Afficher_picross(*nonogram);
}

void solveur(picross* picroSSSS, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) { //pour l'instant un void, apres il retournera si il a trouv� ou non une chose a modifier
    printf("Le debut de cette iteration est %d et sa fin est %d\n\n\n",debut, longueur);
    int casevide = 0;
    for (int testcasei = debut; testcasei <= longueur; testcasei++)//on parcourt toute les cases pour essayer de trouver un "vide" sur la ligne, sinon, pas la peine de continuer et de chercher a modifier
    {
        if (mode == Ligne) {if (picroSSSS->solution[testcasei + picroSSSS->colonnes * nb_coligne] == VIDE) casevide++;}
        if (mode == Colonne) { if (picroSSSS->solution[nb_coligne + picroSSSS->colonnes * testcasei] == VIDE) casevide++; }
    }



    if (casevide) { //si il y a au moins une case a remplir, on remplit, sinon, pas la peine

        evidences(picroSSSS, instruction, debut, longueur,nb_coligne,nbr_instruc,mode); //(on le fait quand meme, meme s'il est refait dans solveur pour les cas ou il n'y a qu'une instruction)
        if (nbr_instruc == 1) {
            if (nb_coligne == 0 && mode == Colonne) {
                printf("\n\n endroit 1\n");
                Afficher_picross(*picroSSSS);
            }
            for (int i = debut; i <= longueur; i++) {
                if ((mode==Ligne && picroSSSS->solution[i+picroSSSS->colonnes*nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes*i] == PLEIN)) {
                    //car nombre element vaut 1, l'instruction dans cette ligne est donc *instruction

                    for (int k = debut; k <= longueur - *instruction; k++) { //voir https://discordapp.com/channels/@me/709012413369942056/710055010775597139
                        if (i - k - 1 < debut) {
                            if(mode == Ligne) picroSSSS->solution[longueur - (k - i) + picroSSSS->colonnes*nb_coligne] = CROIX;
                            if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * (longueur - (k - i))] = CROIX;
                        }
                        if (k <= i - *instruction) {
                            if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                            if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                        }
                    }
                }

                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == CROIX)) && *instruction > longueur - i) { // Reduire la taille de la ligne si l'instruction ne passe pas entre une case "CROIX" et la fin
                    for (int k = i; k <= longueur; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                    }
                    evidences(picroSSSS, instruction, 0, i - 1, nb_coligne, nbr_instruc, mode);
                    //printf("\nTest\n");
                }
                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == CROIX)) && *instruction > i) { // Reduire la taille de la ligne si l'instruction ne passe pas entre une case "CROIX" et le debut
                    for (int k = debut; k <= i; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                    }
                    evidences(picroSSSS, instruction, i + 1, longueur, nb_coligne, nbr_instruc, mode);
                }
            }
            if (nb_coligne == 0 && mode == Colonne) {
                printf("\n\navant while\n");
                Afficher_picross(*picroSSSS);
            }
            int i = debut; int j = longueur;
            int modif = 0;
            while (i < longueur && j>debut && modif == 0) //rempli entre 2 cases noircie lorsqu'il n'y a qu'une seule instruction
            {
                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == PLEIN)) && ((mode == Ligne && picroSSSS->solution[j + picroSSSS->colonnes * nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * j] == PLEIN))) { //rajouter une verification si j-i plus grand que instruction 

                    for (int k = i; k < j; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = PLEIN;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = PLEIN; //il faudra peut etre verifier que ce n'est pas une case "CROIX" auquel cas -> remonter une erreur car impossible
                    }
                    modif = 1;
                }
                if ((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] != PLEIN)) {
                    i++;
                }
                if ((mode == Ligne && picroSSSS->solution[j + picroSSSS->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * j] != PLEIN) ) {
                    j--;
                }
            }
        }

        if (nb_coligne == 0 && mode == Colonne) {
            printf("\napres while\n");
            Afficher_picross(*picroSSSS);
        }
        if ((mode == Ligne && picroSSSS->solution[debut + nb_coligne * picroSSSS->colonnes] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + debut * picroSSSS->colonnes] == CROIX)) {
            if (debut + 1 < longueur) {
                solveur(picroSSSS, instruction, debut + 1, longueur, nb_coligne, nbr_instruc, mode);
            }
        }
        else {
            int espace = espacement(picroSSSS, debut, 1, nb_coligne, mode);
            if (espace < *instruction) { // Reduire la taille de la ligne si la premiere instruction ne passe pas entre une case "CROIX" et le debut

                printf("l'espace vaut: %d et l'instruction vaut:%d", espace, *(instruction));
                for (int k = debut; k < debut + espace ; k++) {
                    if(mode==Ligne) picroSSSS->solution[k + picroSSSS->colonnes*nb_coligne] = CROIX;
                    if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;

                }
                printf("instruc debut");
                printf("La fonction solveur va etre reappeler avec comme parametre de debut et de fin:%d et %d ", debut +1 + espace, longueur );
                solveur(picroSSSS, instruction, espace + 1 + debut, longueur,nb_coligne,nbr_instruc,mode);
            }
        }
        if ((mode == Ligne && picroSSSS->solution[longueur + nb_coligne * picroSSSS->colonnes] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + longueur * picroSSSS->colonnes]==CROIX)) { // Reduire la taille de la ligne si la derniere instruction ne passe pas entre une case "CROIX" et la 
            if (debut+1<longueur) { solveur(picroSSSS, instruction, debut, longueur - 1, nb_coligne, nbr_instruc, mode); }
        }
        else {
            int espace = espacement(picroSSSS, longueur, -1, nb_coligne, mode);

            if (espace < *(instruction +  nbr_instruc -1)) {
                for (int k = longueur - espace; k < longueur; k++) {
                    if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                    if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;

                }
                printf("instruc fin\n");
                printf("La fonction solveur va etre reappeler avec comme parametre de debut et de fin:%d et %d ", debut, longueur - 1 - espace);
                solveur(picroSSSS, instruction, debut, longueur -1 -espace , nb_coligne, nbr_instruc, mode);
            }
        }
       
       
       mettre_des_croix_autour(picroSSSS, instruction, debut, longueur, nb_coligne, nbr_instruc, mode);
       //division(picroSSSS, instruction, longueur, nb_coligne, nbr_instruc, mode);
    }
    if (nb_coligne == 0 && mode == Colonne) {
        Afficher_picross(*picroSSSS);
    }
}

void parcourt_ligne_et_colonne(picross* nonogram) {
    int nb2cases;
    int* ptr;
    int* chang = (int*)malloc(sizeof(int) * nonogram->lignes * nonogram->colonnes);
    if (chang == NULL) return;
    for (int x = 0; x < nonogram->lignes; x++) {
        for (int y = 0; y < nonogram->colonnes; y++) {
            *(chang +y + x * nonogram->colonnes)= 0;
        }
    }
    do{
        for (int i = 0; i < nonogram->lignes; i++) {
            printf("-------------------------- %d eme ligne --------------------------\n", i);
            nb2cases = trouver_cases_max2(nonogram->nb_lignes[i]);
            ptr = instructions_tableau_simple(nonogram->nb_lignes[i], i, nb2cases);
            solveur(nonogram, ptr, 0, nonogram->colonnes - 1, i, nb2cases, Ligne);
            division(nonogram, ptr, nonogram->colonnes - 1, i, nb2cases, Ligne);
            coligne_complet(nonogram,ptr,0,nonogram->colonnes -1,i,nb2cases,Ligne);
            //Afficher_picross(*nonogram);*/
            //printf("\n%s\n", nonogram->nb_colonnes[2]);
            free(ptr);
            Afficher_picross(*nonogram);
        }

        printf("\n");
        for (int i = 0; i < nonogram->colonnes; i++) {
            printf("------------------------- %d eme colonne -------------------------\n", i);
            //if(i==2)
            //printf("\n%s\n", nonogram->nb_colonnes[2]);
            nb2cases = trouver_cases_max2(nonogram->nb_colonnes[i]);
            ptr = instructions_tableau_simple(nonogram->nb_colonnes[i], i, nb2cases);
            solveur(nonogram, ptr, 0, nonogram->lignes - 1, i, nb2cases, Colonne);
            division(nonogram, ptr, nonogram->lignes - 1, i, nb2cases, Colonne);
            coligne_complet(nonogram, ptr, 0, nonogram->lignes- 1, i, nb2cases, Colonne);
            //Afficher_picross(*nonogram);*/
            //if(i==2)
            //printf("\n%s\n", nonogram->nb_colonnes[2]);
            free(ptr);
            Afficher_picross(*nonogram);
        }
        printf("\n");
    } while (changement(*nonogram, chang) == 1);
}

int Init_picross(picross* tmp, int lignes, int colonnes) {
    if (lignes <= 0 || colonnes <= 0)return ERROR;
    //D�claration des variables
    picross* resultat;
    int* tmp1;
    char** tmp2;
    char** tmp3;
    //Allocation de la m�moire pour les tableaux
    resultat = (picross*)malloc(sizeof(picross));

    tmp1 = (int*)malloc(sizeof(int) * lignes * colonnes);

    tmp2 = (char**)malloc(sizeof(char*) * lignes);
    for (int i = 0; i < lignes; i++)
        tmp2[i] = (char*)malloc(sizeof(char) * SIZEMAX);

    tmp3 = (char**)malloc(sizeof(char*) * colonnes);
    for (int i = 0; i < colonnes; i++)
        tmp3[i] = (char*)malloc(sizeof(char) * SIZEMAX);

    //Check si les allocation on r�ussi
    if (!resultat || !tmp1 || !tmp2 || !tmp3)return ERROR;
    //On rends des tableux vide
    for (int x = 0; x < lignes; x++)
        for (int y = 0; y < colonnes; y++)
            tmp1[y + x * colonnes] = 0;

    for (int i = 0; i < lignes; i++) {
        sprintf_s(tmp2[i], SIZEMAX, "%d", 0);
        tmp2[i];
    }

    for (int i = 0; i < colonnes; i++) {
        sprintf_s(tmp3[i], SIZEMAX, "%d", 0);
        tmp3[i];
    }

    //Assignation des valeurs aux variables    
    tmp->lignes = lignes;
    tmp->colonnes = colonnes;
    tmp->nb_cases = 0;
    tmp->solution = tmp1;
    tmp->nb_lignes = tmp2;
    tmp->nb_colonnes = tmp3;
    return OK;
}