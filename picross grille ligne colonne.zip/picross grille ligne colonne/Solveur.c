#include "extraire.h"

int main() {
    setlocale(LC_ALL, "fr-FR");

    int colonnes = 7;
    int lignes = 7;
    picross Piiicross;
    if (Init_picross(&Piiicross, lignes, colonnes)) {
        printf("\n\n%d\n\n", Piiicross.colonnes);
        Piiicross.nb_lignes[0] = "6"; //on defini les differentes informations des lignes
        Piiicross.nb_lignes[1] = "6";
        Piiicross.nb_lignes[2] = "2";
        Piiicross.nb_lignes[3] = "3";
        Piiicross.nb_lignes[4] = "1 3";
        Piiicross.nb_lignes[5] = "1 3";
        Piiicross.nb_lignes[6] = "1 2";

        Piiicross.nb_colonnes[0] = "2";
        Piiicross.nb_colonnes[1] = "2 2";
        Piiicross.nb_colonnes[2] = "2 1";
        Piiicross.nb_colonnes[3] = "2 4";
        Piiicross.nb_colonnes[4] = "6";
        Piiicross.nb_colonnes[5] = "3 3";
        Piiicross.nb_colonnes[6] = "1";


        Piiicross.solution[5 + Piiicross.colonnes*5] = PLEIN;
        Afficher_picross(Piiicross);
        //printf("%d", espacement(&Piiicross, 0, 1, 2, Ligne));
    parcourt_ligne_et_colonne(&Piiicross);
    Afficher_picross(Piiicross);
    }
}