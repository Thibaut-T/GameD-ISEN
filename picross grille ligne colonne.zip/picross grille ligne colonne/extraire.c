#include "extraire.h"

int trouver_cases_max2(char* nb[], int nb_case) {
    return (int)((strlen(*(nb + nb_case)) + 1) / 2);
}



int* instructions_tableau_simple(char* nb, int nb_case, int cases_max) {
    int* nb_tableau_simple = (int*)malloc(sizeof(int) * cases_max);
    char* chaine;
    char* end;
    chaine = nb;
    for (int i = 0; i < cases_max; i++) {
        *(nb_tableau_simple + i) = (int)strtol(chaine, &end, 10);
        chaine = end;
    }
    return nb_tableau_simple;
}


void Afficher_picross(picross tmp) {
    printf("\nNombre de cases remplie : %d", tmp.nb_cases);
    printf("\nNombre de colonnes remplie : %d", tmp.colonnes);
    printf("\nNombre de lignes remplie : %d\n", tmp.lignes);

    for (int x = 0; x < tmp.lignes; x++) {
        for (int y = 0; y < tmp.colonnes; y++)
            printf("%d ", tmp.solution[y + x * tmp.colonnes]);
        printf("\n");
    }
}


void evidences(picross* Picross, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) {
    int taillecompresse = 0;
    //printf("evidences");
    for (int i = 0; i < nbr_instruc; i++) {
        taillecompresse += *(instruction + i) + 1;
    }
    taillecompresse--;

    //printf("La taille compress�e de la ligne est %d", taillecompresse);
    int vartemp;
    int tmp = debut;
    int marge = longueur - debut - taillecompresse + 1;
    
    printf("\nla marge est de %d\n\n", marge);
    for (int i = 0; i < nbr_instruc; i++) {
        if (marge < *(instruction + i)) {
            printf("\n%d", instruction[i] - marge);
            for (int j = 0; j < instruction[i] - marge; j++) {
                if(mode==Ligne) Picross->solution[tmp + j + marge + Picross->colonnes * nb_coligne] = PLEIN;
                if (mode == Colonne) Picross->solution[nb_coligne + Picross->colonnes*(marge+j+tmp)] = PLEIN;
                printf("La %d eme case a ete modifi�\n", tmp + j);
            }
            if (marge == 0 && tmp + *(instruction + i) + 1 <= longueur) {
                vartemp = *(instruction + i) + tmp;
                if(mode==Ligne) Picross->solution[vartemp + Picross->colonnes * nb_coligne] = CROIX;
                if (mode == Colonne) Picross->solution[nb_coligne + Picross->colonnes*vartemp]=CROIX;
            }
        }
        tmp += *(instruction + i) + 1;
    }
}



int changement(picross nonogram, int* chang) {
    int changement = 0;
    for (int i = 0; i < nonogram.lignes; i++) {
        for (int y = 0; y < nonogram.colonnes; y++) {
            if (nonogram.solution[y + i * nonogram.colonnes] != *(chang +y + i * nonogram.colonnes)) {
                changement++;
                
                *(chang +y + i*nonogram.colonnes) = nonogram.solution[y + i * nonogram.colonnes];
            }
        }
    }

    if (changement==0) {
        return 0;
    }
    else {
        return 1;
    }
}

int espacement(picross* nonogram, int caseini, int ordre, int nb_coligne, int mode) {
    int nbvide = 0;
    int pos = caseini;
    while ((mode==Ligne && pos < nonogram->colonnes && nonogram->solution[pos + nonogram->colonnes*nb_coligne] != CROIX) || (mode==Colonne && nonogram->solution[nb_coligne + pos*nonogram->colonnes] != CROIX && pos<nonogram->lignes) && pos >= 0) {
        pos += ordre;
        nbvide++;
    }
    return nbvide;
}

void coligne_complet(picross* nonogram, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) {
    int cases_a_noircir = 0;
    for(int i=0;i<nbr_instruc;i++){
        cases_a_noircir += instruction[i];
    }
    int nbr_cases_noir_actu;
    for (int i = debut; i <= longueur; i++) {
        if (mode == Ligne && nonogram->solution[i + nonogram->colonnes * nb_coligne]==PLEIN)  nbr_cases_noir_actu++;
        if (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * i]==PLEIN) nbr_cases_noir_actu++;
    }
    if (nbr_cases_noir_actu==cases_a_noircir) {
        for(int i=debut;i<=longueur;i++){

            if ((mode == Ligne && nonogram->solution[i + nonogram->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && nonogram->solution[nb_coligne + nonogram->colonnes * i] != PLEIN)) 
            {
                if (mode == Ligne) nonogram->solution[i + nonogram->colonnes * nb_coligne] = CROIX;
                if (mode == Colonne) nonogram->solution[nb_coligne + nonogram->colonnes * i] = CROIX;
            }
        }
    }
}

void solveur(picross* picroSSSS, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode) { //pour l'instant un void, apres il retournera si il a trouv� ou non une chose a modifier

    int casevide = 0;
    for (int testcasei = debut; testcasei <= longueur; testcasei++)//on parcourt toute les cases pour essayer de trouver un "vide" sur la ligne, sinon, pas la peine de continuer et de chercher a modifier
    {
        if (mode == Ligne) {if (picroSSSS->solution[testcasei + picroSSSS->colonnes * nb_coligne] == VIDE) casevide++;}
        if (mode == Colonne) { if (picroSSSS->solution[nb_coligne + picroSSSS->colonnes * (testcasei)] == VIDE) casevide++; }
    }

    if (casevide) { //si il y a au moins une case a remplir, on remplit, sinon, pas la peine

        evidences(picroSSSS, instruction, debut, longueur,nb_coligne,nbr_instruc,mode); //(on le fait quand meme, meme s'il est refait dans solveur pour les cas ou il n'y a qu'une instruction)
        if (nbr_instruc == 1) {
            for (int i = debut; i <= longueur; i++) {
                if ((mode==Ligne && picroSSSS->solution[i+picroSSSS->colonnes*nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes*i] == PLEIN)) {
                    //car nombre element vaut 1, l'instruction dans cette ligne est donc *instruction

                    for (int k = debut; k <= longueur - *instruction; k++) { //voir https://discordapp.com/channels/@me/709012413369942056/710055010775597139
                        if (i - k - 1 < debut) {
                            if(mode == Ligne) picroSSSS->solution[longueur - (k - i) + picroSSSS->colonnes*nb_coligne] = CROIX;
                            if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * (longueur - (k - i))] = CROIX;
                        }
                        if (k <= i - *instruction) {
                            if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                            if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                        }
                    }
                }
                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == CROIX)) && *instruction > longueur - i) { // Reduire la taille de la ligne si l'instruction ne passe pas entre une case "CROIX" et la fin
                    for (int k = i; k <= longueur; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                    }
                    evidences(picroSSSS, instruction, 0, i - 1, nb_coligne, nbr_instruc, mode);
                    //printf("\nTest\n");
                }
                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == CROIX)) && *instruction > i) { // Reduire la taille de la ligne si l'instruction ne passe pas entre une case "CROIX" et le debut
                    for (int k = debut; k <= i; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;
                    }
                    evidences(picroSSSS, instruction, i + 1, longueur, nb_coligne, nbr_instruc, mode);
                }
            }

            int i = debut; int j = longueur;
            int modif = 0;
            while (i < longueur && j>debut && modif == 0) //rempli entre 2 cases noircie lorsqu'il n'y a qu'une seule instruction
            {
                if (((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] == PLEIN)) && ((mode == Ligne && picroSSSS->solution[j + picroSSSS->colonnes * nb_coligne] == PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * j] == PLEIN))) { //rajouter une verification si j-i plus grand que instruction 

                    for (int k = i; k <= j; k++)
                    {
                        if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = PLEIN;
                        if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = PLEIN; //il faudra peut etre verifier que ce n'est pas une case "CROIX" auquel cas -> remonter une erreur car impossible
                    }
                    modif = 1;
                }
                if ((mode == Ligne && picroSSSS->solution[i + picroSSSS->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * i] != PLEIN)) {
                    i++;
                }
                if ((mode == Ligne && picroSSSS->solution[j + picroSSSS->colonnes * nb_coligne] != PLEIN) || (mode == Colonne && picroSSSS->solution[nb_coligne + picroSSSS->colonnes * j] != PLEIN) ) {
                    j--;
                }
            }
        }
        if ((mode == Ligne && picroSSSS->solution[debut + nb_coligne * picroSSSS->colonnes] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + debut * picroSSSS->colonnes]) == CROIX) {
            if (debut + 1 < longueur) {
                solveur(picroSSSS, instruction, debut + 1, longueur, nb_coligne, nbr_instruc, mode);
            }
        }
        else {
            int espace = espacement(picroSSSS, debut, 1, nb_coligne, mode);
            if (espace < *instruction) { // Reduire la taille de la ligne si la premiere instruction ne passe pas entre une case "CROIX" et le debut
                for (int k = debut; k < debut + espace; k++) {
                    if(mode==Ligne) picroSSSS->solution[k + picroSSSS->colonnes*nb_coligne] = CROIX;
                    if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;

                }
                solveur(picroSSSS, instruction, espace + 1 + debut, longueur,nb_coligne,nbr_instruc,mode);
            }
        }
        if ((mode == Ligne && picroSSSS->solution[longueur + nb_coligne * picroSSSS->colonnes] == CROIX) || (mode == Colonne && picroSSSS->solution[nb_coligne + (longueur - 1) * picroSSSS->colonnes]==CROIX)) { // Reduire la taille de la ligne si la derniere instruction ne passe pas entre une case "CROIX" et la 
            if (debut+1<longueur) { solveur(picroSSSS, instruction, debut + 1, longueur, nb_coligne, nbr_instruc, mode); }
        }
        else {
            int espace = espacement(picroSSSS, longueur, -1, nb_coligne, mode);
            if (espace < *(instruction +  nbr_instruc - 1)) {
                for (int k = longueur - espace; k < longueur; k++) {
                    if (mode == Ligne) picroSSSS->solution[k + picroSSSS->colonnes * nb_coligne] = CROIX;
                    if (mode == Colonne) picroSSSS->solution[nb_coligne + picroSSSS->colonnes * k] = CROIX;

                }
                solveur(picroSSSS, instruction, debut, longueur - espace - 1,nb_coligne,nbr_instruc ,mode);
            }
        }
        coligne_complet(picroSSSS, instruction, debut, longueur, nb_coligne, nbr_instruc, mode);
    }
}



void parcourt_ligne_et_colonne(picross* nonogram) {
    int nb2cases;
    int* ptr;
    int* chang = (int*)malloc(sizeof(int) * nonogram->lignes * nonogram->colonnes);
    if (chang == NULL) return;
    for (int x = 0; x < nonogram->lignes; x++) {
        for (int y = 0; y < nonogram->colonnes; y++) {
            *(chang +y + x * nonogram->colonnes)= 0;
        }
    }
    do{
        for (int i = 0; i < nonogram->lignes; i++) {
            //printf("--------------------------%d eme ligne --------------------------", i);
            nb2cases = trouver_cases_max2(nonogram->nb_lignes, i);
            ptr = instructions_tableau_simple(nonogram->nb_lignes[i], i, nb2cases);
            solveur(nonogram, ptr, 0, nonogram->colonnes-1, i, nb2cases, Ligne);
            //Afficher_picross(*nonogram);*/
        }
        for (int i = 0; i < nonogram->colonnes; i++) {
             //printf("--------------------------%d eme colonne --------------------------", i);
            nb2cases = trouver_cases_max2(nonogram->nb_colonnes, i);
            ptr = instructions_tableau_simple(nonogram->nb_colonnes[i], i, nb2cases);
            solveur(nonogram, ptr, 0, nonogram->lignes-1, i, nb2cases, Colonne);
            //Afficher_picross(*nonogram);*/
        }
    } while (changement(*nonogram, chang) == 1);
}





int Init_picross(picross* tmp, int lignes, int colonnes) {
    if (lignes <= 0 || colonnes <= 0)return ERROR;
    //D�claration des variables
    picross* resultat;
    int* tmp1;
    char** tmp2;
    char** tmp3;
    //Allocation de la m�moire pour les tableaux
    resultat = (picross*)malloc(sizeof(picross));

    tmp1 = (int*)malloc(sizeof(int) * lignes * colonnes);

    tmp2 = (char**)malloc(sizeof(char*) * lignes);
    for (int i = 0; i < lignes; i++)
        tmp2[i] = (char*)malloc(sizeof(char) * SIZEMAX);

    tmp3 = (char**)malloc(sizeof(char*) * colonnes);
    for (int i = 0; i < colonnes; i++)
        tmp3[i] = (char*)malloc(sizeof(char) * SIZEMAX);

    //Check si les allocation on r�ussi
    if (!resultat || !tmp1 || !tmp2 || !tmp3)return ERROR;
    //On rends des tableux vide
    for (int x = 0; x < lignes; x++)
        for (int y = 0; y < colonnes; y++)
            tmp1[y + x * colonnes] = 0;

    for (int i = 0; i < lignes; i++) {
        sprintf_s(tmp2[i], SIZEMAX, "%d", 0);
        tmp2[i];
    }

    for (int i = 0; i < colonnes; i++) {
        sprintf_s(tmp3[i], SIZEMAX, "%d", 0);
        tmp3[i];
    }

    //Assignation des valeurs aux variables    
    tmp->lignes = lignes;
    tmp->colonnes = colonnes;
    tmp->nb_cases = 0;
    tmp->solution = tmp1;
    tmp->nb_lignes = tmp2;
    tmp->nb_colonnes = tmp3;
    return OK;
}