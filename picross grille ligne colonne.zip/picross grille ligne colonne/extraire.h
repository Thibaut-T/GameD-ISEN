#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <conio.h>
#include <locale.h>
#include <string.h>
#pragma once
#define VIDE 0 //On ne conna�t pas encore l'�tat de la case
#define PLEIN 1 //pas besoin d'explication
#define CROIX 2 //On est s�r que la case est vide
#define MARQUEUR 3 //c'est peut etre plein
#define ERROR -1
#define SIZEMAX 20
#define OK 100
#define TailleTab 5
#define Ligne 1 //permet au solveur de savoir si l'on traite d'une ligne
#define Colonne 2 //permet au solveur de savoir si l'on traite d'une colonne

typedef struct picross {
    int lignes; //Le nombre de lignes de la solution.
    int colonnes; //Le nombre de colonnes de la solution.
    int* solution; //Le tableau contenant la solution.
    int nb_cases; //Le nombre de cases � remplir au total.
    char** nb_lignes; //Le nombre de cases � remplir par ligne.
    char** nb_colonnes; //Le nombre de cases � remplir par colonne.
} picross;


void Afficher_picross(picross tmp);

int changement(picross nonogram, int* chang);

void coligne_complet(picross* picroSSSS, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode);

int espacement(picross* nonogram, int caseini, int ordre, int nb_coligne, int mode);

void evidences(picross* Picross, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode);

int Init_picross(picross* tmp, int lignes, int colonnes);

int* instructions_tableau_simple(char* nb, int nb_case, int cases_max);

void parcourt_ligne_et_colonne(picross* nonogram);

void solveur(picross* picroSSSS, int* instruction, int debut, int longueur, int nb_coligne, int nbr_instruc, int mode);

int trouver_cases_max2(char* nb[], int nb_case);


